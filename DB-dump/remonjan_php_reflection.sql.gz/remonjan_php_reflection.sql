-- MySQL dump 10.13  Distrib 8.0.27, for Linux (x86_64)
--
-- Host: localhost    Database: remonjan_php_reflection
-- ------------------------------------------------------
-- Server version	8.0.27

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `contactform_data`
--

DROP TABLE IF EXISTS `contactform_data`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `contactform_data` (
  `name` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `email` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `telephone` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `subject` text CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `message` longtext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `timestamp` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `contactform_data`
--

LOCK TABLES `contactform_data` WRITE;
/*!40000 ALTER TABLE `contactform_data` DISABLE KEYS */;
INSERT INTO `contactform_data` (`name`, `email`, `telephone`, `subject`, `message`, `timestamp`) VALUES ('1','1@1.com','1','1','1','2022-01-06 16:59:56'),('1','1@1.com','1','1','1','2022-01-06 17:06:14'),('1','1@1.com','1','1','1&lt;img&gt;','2022-01-06 17:08:01'),('1','1@1.com','1','1','1&lt;img&gt;','2022-01-06 17:13:48'),('1','1@1.com','1','1','1','2022-01-06 17:14:16'),('1','1','1','1','1','2022-01-07 08:50:50'),('1','1@1.com','1','1','1','2022-01-07 08:54:54'),('1','1@1.com','1','1','1','2022-01-07 10:01:29'),('1','1@1.com','1','1','1','2022-01-07 10:04:17'),('1','1@1.com','1','1','1','2022-01-07 10:05:50'),('1','1@1.com','1','1','1','2022-01-07 10:10:36'),('1','1@1.com','1','1','1','2022-01-07 10:11:29'),('1','1@1.com','1','1','1','2022-01-07 10:18:46'),('1','1@1.com','1','1','1','2022-01-07 10:27:33'),('1','1@1.com','1','1','1','2022-01-10 15:40:29'),('1','1@1.com','1','1','1','2022-01-12 11:11:13'),('1','1@1.com','1','1','1','2022-01-12 11:16:51'),('fdssfd','sfdsfd@gff.df','43543534534','dfgfgd','fgdfgd','2022-01-12 11:58:42'),('1','1@1.com','1','1','1','2022-01-12 12:27:26'),('scott','scott.hellings@netmatters-scs.com','11111111111','11111111','1111111111111111111','2022-01-12 12:31:46'),('1','1@1.cc','1','1','1','2022-01-12 12:40:10'),('aa','1@1.com','1111111111','1','1','2022-01-12 17:01:49'),('Aa','1@1.cc','1111111111','1','1','2022-01-12 17:06:48'),('asdf','test@test.com','1111111111','1','1','2022-01-12 17:15:17'),('Aa','1@1.cc','1111111111','1','1','2022-01-12 17:18:32'),('Aa','1@1.cc','1111111111','1','This has all the same values except the message, which is longer','2022-01-12 17:20:31'),('Aa','1@1.cc','1111111111','1','Shorter body, box is ticked','2022-01-12 17:21:29'),('Stephen Bernard','test@test.com','1234567890','Test','This is a test email','2022-01-12 17:23:22'),('aa aa','1@1.com','1111111111','aa','aaaaa','2022-01-12 17:23:39'),('Stephen Bernard','test@test.com','1234567890','Test Subject','Another test','2022-01-12 17:24:21');
/*!40000 ALTER TABLE `contactform_data` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `netmatters_news`
--

DROP TABLE IF EXISTS `netmatters_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `netmatters_news` (
  `postID` int DEFAULT NULL,
  `header_img` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `category` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `subcategory` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `colour` varchar(50) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `title` varchar(150) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `message` mediumtext CHARACTER SET utf8 COLLATE utf8_unicode_ci,
  `user_name` varchar(100) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_avatar` varchar(250) CHARACTER SET utf8 COLLATE utf8_unicode_ci DEFAULT NULL,
  `date` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `netmatters_news`
--

LOCK TABLES `netmatters_news` WRITE;
/*!40000 ALTER TABLE `netmatters_news` DISABLE KEYS */;
INSERT INTO `netmatters_news` (`postID`, `header_img`, `category`, `subcategory`, `colour`, `title`, `message`, `user_name`, `user_avatar`, `date`) VALUES (1,'https://www.netmatters.co.uk/assets/images/thumbnails/thumb/rob-becomes-a-NjF3.jpg','news','IT Support','itsupport','\"Rob Becomes a Netmatters Director\"','Netmatters is constantly evolving and day-by-day it continues to grow in every aspect. Despite a tough year for the world, we have continued that growth and, with this in mind, it is with great pleasure that we announce we have appointed a new director.\r\n\r\nRobert George has been promoted to our IT Service Director! Formerly a Service Manager, a promotion has earned Rob a new title within the company.\r\n\r\nRob has proved himself as a very capable member of the team and has helped shape our IT service delivery over the last 4 years. His new role will see him take on more responsibility and help ensure we continue to deliver excellent service for all our customers. - James Gulliver. Managing Director\r\nRob originally joined Netmatters as a Business Development executive. It quickly became evident that Rob couldn’t sell chips to a starving man so we redeployed him to the position of Service Manager, where his particular skill set was more suited. During his time in this role, Rob successfully helped improve standards as the department has evolved and grown. He has been a true advocate for Netmatters and a stalwart supporter of leading by example.\r\n\r\nIt\'s been exciting to see how Netmatters has grown over the past few years and how the team has evolved. I am incredibly proud to be offered the opportunity of becoming a Director at Netmatters and I look forward to being a part of the business moving forwards. - Rob George, IT Service Director\r\nWe are continuously looking to grow the company with a strategy that will help empower all employees and lead them to have successful careers within Netmatters. Using innovation, technology, creativity, and vision our team continues to improve in skills and numbers, resulting in the delivery of positive results for all of our clients.\r\n\r\nOur services that we provide as an overall company covers various technology business needs and solutions such as, Website Development, Software Development, Digital Marketing, IT Support, Telecoms. If you are interested in any of these services, please do get in contact via the form below, or by ringing 01603 704020. ','Netmatters Ltd','https://www.netmatters.co.uk/assets/images/thumbnails/article_contact_thumb/netmatters-ltd-VXAv.webp','2021-04-21'),(2,'https://www.netmatters.co.uk/assets/images/thumbnails/thumb/netmatters-company-cars-MNGC.jpg','environmental','news','webdesign','Netmatters Company Cars Go Green!','As part of our ongoing quest to find ways of reducing our environmental impact as a company we have recently taken steps to update our company car policy.','Chris Gulliver','https://www.netmatters.co.uk/assets/images/thumbnails/article_contact_thumb/chris-gulliver-PVWc.webp','2021-04-21'),(3,'https://www.netmatters.co.uk/assets/images/thumbnails/thumb/april-2021-notables-CIV3.webp','news','telecoms services','telecoms','April 2021 Notables','Every month we celebrate the most notable of employees here at Netmatters. Each department he...','Netmatters Ltd','https://www.netmatters.co.uk/assets/images/thumbnails/article_contact_thumb/netmatters-ltd-VXAv.webp','2021-05-06'),(4,'https://www.netmatters.co.uk/assets/images/thumbnails/thumb/congratulations-to-lloyd-D2cu.jpg','news','web design','webdesign','Congratulations to Lloyd Cox for Graduating the SCS!','We are pleased to announce that after a year spent on our Netmatters Scion Coalition Scheme (... ','Netmatters Ltd','https://www.netmatters.co.uk/assets/images/thumbnails/article_contact_thumb/netmatters-ltd-VXAv.webp','2021-05-10'),(5,'https://www.netmatters.co.uk/assets/images/thumbnails/thumb/senior-it-support-Vfd9.jpg','careeers','IT Support','itsupport','Senior IT Support Technician','Salary Ra... <br class=\"cardspacer345\">&nbsp;<br class=\"cardspacer345\">&nbsp;<br class=\"cardspacer992\">&nbsp;<br class=\"cardspacer1260\">&nbsp;<br class=\"cardspacer1260\">&nbsp;','Rob George','https://www.netmatters.co.uk/assets/images/thumbnails/article_contact_thumb/rob-george-zFWY.jpg','2021-05-17');
/*!40000 ALTER TABLE `netmatters_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'remonjan_php_reflection'
--

--
-- Dumping routines for database 'remonjan_php_reflection'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-01-12 17:34:30
