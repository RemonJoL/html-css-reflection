const menuBtn = document.querySelector(".btn-menu-icon-cnt");
const mainElement = document.querySelector(".main");
const overlay = document.querySelector(".sidemenu-overlay");
const body = document.body;
// let menuOpen = false;

document.querySelector(".header-menu-btn").addEventListener("click", function(){
  mainElement.classList.add("main-active")
  overlay.style.visibility = "visible"
  // body.style.overflow = "hidden"
  menuBtn.classList.add("open");
  // menuOpen = true;
});

document.querySelector(".sidemenu-overlay").addEventListener("click", function(){
    mainElement.classList.remove("main-active")
    overlay.style.visibility = "hidden"
    body.style.overflow = "auto"
    menuBtn.classList.remove("open");
    // menuOpen = false;
});

// document.addEventListener("click", sideMenu());

// window.addEventListener("scroll", function(){
//   document.querySelector(".header-wrapper").style.position = "fixed";
// });

let previous_value;
let lastScrollTop = 0;
// element should be replaced with the actual target element on which you have applied scroll, use window in case of no target element.
document.querySelector(".page-full").addEventListener("scroll", function(){ // or window.addEventListener("scroll"....
   let value = document.querySelector(".page-full").scrollTop || document.documentElement.scrollTop; // Credits: "https://github.com/qeremy/so/blob/master/so.dom.js#L426"
   if (previous_value > value && value <= 0) {
      document.querySelector(".header-container").style.position = "relative";
       document.querySelector(".header-container").style.padding = "0px 0px 0px 0px";
      console.log("top")

   } else if (previous_value > value && value >= 300) {
      document.querySelector(".header-container").classList.remove("scroll-down");
      document.querySelector(".header-container").classList.add("scroll-up");
       document.querySelector(".header-container").style.position = "fixed";
        document.querySelector(".header-container").style.padding = "0px 17px 0px 0px";
      console.log("down")
   } else if (previous_value < value && value >= 400) {
      document.querySelector(".header-container").classList.remove("scroll-up");
      document.querySelector(".header-container").classList.add("scroll-down");
      console.log("down")
   }
  previous_value = value;
   // lastScrollTop = value <= 215 ? 215 : value; // For Mobile or negative scrolling
}, false);

// document.getElementById("cookieAcceptBtn").addEventListener("click", function() {
//   document.querySelector(".cookie-app").style.display = "none";
//   document.body.style.overflow = "auto";
//   document.body.style.height = "auto";
// });

document.getElementById("cookieAcceptBtn").addEventListener("click", function() {
  document.querySelector(".cookie-app").style.display = "none";
  // document.body.style.overflow = "auto";
  // document.body.style.height = "auto";
});
